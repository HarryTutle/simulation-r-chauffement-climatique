#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Apr  6 15:30:19 2023

@author: harry
"""

import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.tsa.arima_model import ARIMA
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.stattools import adfuller
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from sklearn.metrics import mean_squared_error

from joblib import load, dump

st.title('Modélisation de la température moyenne mondiale.')
st.header("Matrice de corrélation des différentes variables:")
st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\matrice correlation variables")
st.write(" D'après la matrice de corrélations, nous avons pu modéliser la température moyenne mondiale avec la variable temps ('year'), la variable co2 moyenne mondiale ('co2') et des variables géographiques. On a donc fait trois modèles avec des approches différentes; une approche directe avec un modèle prédictif sur le temps/latitude/longitude/températures précédentes, une approche avec les séries temporelles, et enfin une approche avec des modèles de régressions linéaires car en observant la matrice on distingue bien des variables fortement corrélées linéairement.")
st.write("La finalité de tout ces modèles est de tenter de prédire la température moyenne mondiale en 2100.")
st.header("Partie 1: méthodologie.")
st.subheader("1.1 Approche directe, forêts aléatoires.")
st.write("Le jeu de données se présente sous forme de tenseur en trois dimensions (temps, latitude, longitude), chaque nombre est donc une température moyenne annuelle à un endroit et une année précise. Il a fallu rédiger un programme pour réagencer ce tenseur sous forme de Dataframe, et en transposant ce dataframe avoir pour chaque échantillon la latitude, longitude et les températures par années gardées dans notre jeu d'entrainement.")
st.subheader("1.2 Approche linéaire générale, régression linéaire.")
st.write("Cette fois le jeu de données est réagencé de façon plus classique en un Dataframe avec quatre dimensions (année, latitude, longitude, température). On va ensuite appliquer une régression linéaire pour obtenir la température selon l'année et la zone géographique. On a également essayé la régression polynomiale pour tenir compte de la forme de la courbe de températures qui n'est en réalité pas exactement linéaire.")
st.subheader("1.3 Approche linéaire par point géographique.")
st.write("on a appliqué ici un modèle de régression différent pour chaque point géographique. Donc cette stratégie par rapport à la précédente prédit l'évolution pour chaque point géographique, mais indépendemment des autres points même à proximité. La régression polynomiale a aussi été utilisée.")
st.subheader("1.4 Métriques utilisées.")
st.write("L'erreur moyenne absolue a été utilisée. Comme il est difficile avec l'approche directe de séparer un dataset en un jeu d'entrainement et un jeu test 80 ans dans le futur (les données avant 1960 étant disparates), les différents modèles ont été testés sur leur capacité à prévoir la température de l'année suivante (année suivant la dernière année du jeu d'entrainement).")
st.write("Pour les modèles on a arrêté les données traités jusqu'à 2019, puis on a séparé en un train set à 80% et un test set à 20%. Ensuite on a estimé l'erreur entre les données prédites du jeu test et les données réelles pour 2020.")
st.subheader("Résultats des différents modèles dans leur capacité à prévoir la température de l'année suivante:")
fig, ax=plt.subplots()
ax.bar(["forêts aléatoires","approche linéaire générale","approche linéaire polynomiale générale","approche linéaire par point","approche linéaire polynomiale par point"], [0.06, 0.62, 0.88, 0.69, 0.64], color=['red', 'orange', 'grey', 'yellow', 'green' ] )
plt.xticks(rotation=90)
plt.title("Erreur moyenne absolue selon les modèles.")
plt.ylabel('Erreur absolue moyenne.')
st.pyplot(fig)
st.subheader("1.5 Limites.")
st.write("D'après notre métrique la modélisation la plus efficace semble être l'approche directe avec les forêts aléatoires. Cependant la métrique ne donne pas la capacité du modèle à prédire 80 années dans le futur, de plus l'erreur augmente d'années en années donc ces résultats sont à prendre avec du recul.")
st.write("De plus le dataset d'origine bien qu'assez complet n'intègre pas certaines zones géographiques (l'Antarctique par exemple) donc cela peut biaiser à la longue les valeurs des températures.")
st.write("Le volume de données est ici conséquent, c'est pourquoi nous n'avons pas pu faire une recherche d'optimisation des paramètres avec un gridsearchcv(chaque session d'entrainement dure au moins 30 minutes), ou même un randomizedsearchcv. Avec une puissance de calcul supplémentaire on aurait pu optimiser le modèle des forêts aléatoires.")

st.subheader("2.1 Les séries temporelles.")
st.write("Notre matrice de corrélations indique une forte corrélation linéaire entre le temps et la température moyenne annuelle. Le temps étant ici mesuré par ans, il n'y a pas de saisonnalité à traiter à priori, nous avons donc exploité le modèle ARIMA des séries temporelles afin de prédire les températures futures, notamment la température moyenne en 2100.")
st.subheader("2.2 Métriques utilisées.")
st.write("Pour optimiser les paramètres et vérifier la stationnarité du modèle, on a utilisé la décomposition de fonction, l'analyse de covariance, le test statistique Ad-Fuller et l'erreur moyenne absolue calculées sur les 20 dernières années.")
st.write("Nous avons trouvé que pour stationnariser le modèle on devait régler le paramètre de différentiation à 1. Pour avoir une optimisation des paramètres, le paramètre AR doit être réglé à 1 et le paramètre MA à 0. L'erreur quadratique moyenne est alors de seulement 0.013.")
st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\courbe erreur arima 110 erreur 0.0128")
st.subheader("2.3 Limites.")
st.write("Ce modèle ne prend en compte que la variable temps pour estimer sa prédiction.")
st.subheader("3.1 Les régressions linéaires.")
st.write("En observant la matrice de corrélations, on constate de fortes corrélations linéaires entre le gaz, le charbon, le pétrole, le ciment, l'expoitation des sols et le co2 émis à l'échelle nationale.")
st.write("A l'échelle mondiale, on distingue une forte corrélation linéaire entre le co2 moyen mondial émis(co2_moy_mon) et la température moyenne mondiale (temperature_moy_mon)")
st.write("Donc ici l'objectif sera de faire un modèle capable de prédire la température moyenne mondiale selon l'exploitation du charbon, du gaz, du pétrole...De certains pays. On va procéder en trois étapes.")
st.subheader("3.2 Régressions linéaires sur les variables causales.")
st.write("On va effectuer une régression linéaire différente pour chaque pays sur ses variables causales(gaz, charbon...). La droite obtenue va nous permettre d'estimer l'évolution de ces variables dans le futur, selon chaque pays. On considère donc dans un premier temps que ces variables vont évoluer linéairement au même rythme qu'entre 1960 et 2020.")
st.subheader("3.3 Régression linéaire pour estimer le co2 émis par pays.")
st.write("Cette fois on va entrainer un nouveau modèle de régression sur les données prédites précédemment, afin de prédire le co2 émis par pays. Ce modèle est entrainé sur tout les pays. Une fois que l'on obtient le co2 émis par pays, on calcule le co2 émis moyen mondial.")
st.subheader("3.4 Régression linéaire pour estimer la température moyenne mondiale.")
st.write("Enfin, on met au point un modèle de régression linéaire pour prédire la température moyenne mondiale à partir du co2 émis moyen mondial, et de l'année.")
st.subheader("3.5 Métriques.")
st.write("La métrique s'est faite en deux étapes, en premier le modèle de prédiction du co2 émis. Comme pour Arima, on a testé ce modèle sur les vingt dernières années.")
st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\perf modele co2 20 dernières années")
st.write("On constate que le modèle est assez précis, ça reste cohérent avec notre matrice de corrélations. L'erreur moyenne absolue est de 0.99.")
st.write("Pour la seconde métrique, on estimé le modèle de prédiction des températures également sur les vingt dernières années.")
st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\perf modele temperatures sur les 20 dernières années")
st.write("Le modèle suit la même direction que la tendance, mais légèrement à la baisse. L'erreur moyenne absolue est de 0.26.")
st.subheader("3.6 Limites.")
st.write("Cette stratégie part du postulat que les pays du monde vont exploiter les variables causant l'émission du co2 de façon linéaire comme entre 1960 et 2020...Alors que ce n'est pas vraiment conforme à la réalité.")
st.write("Certaines variables comme le méthane n'ont pas été intégrées, alors que nous savons qu'elles sont en partie aussi responsables de l'effet de serre.")


st.header("Partie 2: modélisation.")

st.subheader('Evolution mondiale des températures entre 1960 et 2019')
st.write("Avec les données du 'Climate Change Knowledge Portal', et une régression linéaire sur chaque point géographique, l'évolution est visualisée avec le coefficient de la régression pour chaque point. Les points rouges sonts les zones les plus impactées.")
st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\carte evolution temperature.png")
st.subheader('Evolution mondiale des températures pour 2100, 2500 et 2100.')
st.write("Les prédictions sont faites avec différents modèles de machine learning au choix.")
machine_learning_model=st.selectbox('Sélection du modèle de machine learning.', ['forets aléatoires', 'régression linéaire générale', 'régression polynomiale générale', 'régression linéaire par point géographique', 'régression polynomiale par point géographique'])
year_prediction=st.selectbox("Sélection de l'année à prédire.", ['2100', '2500', '3000'])

if (machine_learning_model=='forets aléatoires') and (year_prediction=='2100'):
    
    st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\carte prevision foret 2100")

elif (machine_learning_model=='forets aléatoires') and (year_prediction=='2500'):
    
    st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\carte prediction 2500 foret")
    
elif (machine_learning_model=='forets aléatoires') and (year_prediction=='3000'):
    
    st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\carte prediction foret 3000")
    
elif (machine_learning_model=='régression linéaire par point géographique') and (year_prediction=='2100'):
    
    st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\carte regression lineaire 2100")
    
elif (machine_learning_model=='régression linéaire par point géographique') and (year_prediction=='2500'):
    
    st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\carte linearbypoint prediction 2500")
    
elif (machine_learning_model=='régression linéaire par point géographique') and (year_prediction=='3000'):
    
    st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\carte prediction lineaire 3000")
    
elif (machine_learning_model=='régression polynomiale par point géographique') and (year_prediction=='2100'):
    
    st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\carte prediction poly 2100")
    
elif (machine_learning_model=='régression polynomiale par point géographique') and (year_prediction=='2500'):
    
    st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\carte prediction poly 2500")
    
elif (machine_learning_model=='régression polynomiale par point géographique') and (year_prediction=='3000'):
    
    st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\carte prevision poly 3000")
    
elif (machine_learning_model=='régression linéaire générale') and (year_prediction=='2100'):
    
    st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\carte prevision linear gene2100")

elif (machine_learning_model=='régression linéaire générale') and (year_prediction=='2500'):
    
    st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\carte prevision linear gene 2500")
    
elif (machine_learning_model=='régression linéaire générale') and (year_prediction=='3000'):
    
    st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\carte prevision linear gene 3000")
    
elif (machine_learning_model=='régression polynomiale générale') and (year_prediction=='2100'):
    
    st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\carte prediciotn poly gene2100")
    
elif (machine_learning_model=='régression polynomiale générale') and (year_prediction=='2500'):
    
    st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\carte prediction temperature poly gene2500")

elif (machine_learning_model=='régression polynomiale générale') and (year_prediction=='3000'):
    
    st.image(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\carte prediction 3000 poly gene")
    
    
st.subheader("Evolution de la température avec ARIMA (série temporelle)")
st.write("Le modele ARIMA permet d'estimer dans le temps l'évolution de la température ainsi que du co2.")
st.subheader('A propos de la température, paramètres:')
annee_prediction=st.number_input("Année de prédiction", 2050, 2500, step=50)
differentiation=st.number_input("Ordre de différentiation", 0, 1)
AR=st.number_input("Paramètre du processus AR", 0, 5)
MA=st.number_input("Paramètre du processus MA", 0, 5)

data=pd.read_csv(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\data_temperature_co2_anomalie.csv", index_col=0)
temperature=data[['year', 'température']].groupby('year').agg('mean')
temperature.index=pd.date_range('1960-06-01', '2020-06-01', freq='y')



if differentiation==0:
    diff=temperature
elif differentiation==1:
    diff=temperature.diff().dropna()

    
ax2=seasonal_decompose(diff).plot()
st.subheader("Décomposition des données selon nos paramètres sur la température:")
st.pyplot(ax2)
result2=adfuller(diff.température)

st.subheader("Statistiques AD-Fuller.")
st.write(f"Statistiques ADF: {round(result2[0], 2)}")
st.write(f"P-value: {round(result2[1], 2)}")
if result2[1]<0.05:
    st.write("Le modèle est stationnaire.")
elif result2[1]>=0.05:
    st.write("Le modèle n'est pas stationnaire.")


st.subheader("Autocorrélation partielle de la série.")
ax3=plot_pacf(diff)
st.pyplot(ax3)
st.write("Doit tendre vers 0. Permet surtout visuellement de régler le paramètre AR. S'annule généralement après le paramètre AR.")

st.subheader("Autocorrélation simple de la série.")
ax4=plot_acf(diff)
st.pyplot(ax4)
st.write("Doit également tendre vers 0. S'annule en général après le paramètre MA.")

st.subheader("Prédictions Arima de la température.")

train_arima=temperature[:40]
test_arima=temperature[40:60]
model_erreur=ARIMA(train_arima, order=(AR, differentiation, MA))
prediction_erreur=model_erreur.fit()
pred_erreur=prediction_erreur.predict(start=40, end=59, typ="levels")


model=ARIMA(temperature, order=(AR, differentiation, MA))
prediction_arima=model.fit()
pred_debut=prediction_arima.predict(differentiation, end=60, typ='levels')
ax5=prediction_arima.plot_predict(differentiation, annee_prediction-1960)
st.pyplot(ax5)

if differentiation==0:
    pred_debut=pred_debut[:-1]


pre=prediction_arima.predict(60, end=annee_prediction-1960, typ='levels')
debut=pre[0]
fin=pre[-1]
erreur=mean_squared_error(test_arima, pred_erreur)
st.write(f"Erreur quadratique moyenne: {round(erreur,5)}.")
st.write(f"Différence de température: {round(fin-debut, 2)} degrés Celsius.")



st.subheader("Prédictions des modèles de régression linéaire pour 2100.")

scaler=load(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\scaler_modele_1\scaler_modele_1")
model_1=load(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\modele_lineaire_1\modele_lineaire_1")
model_2=load(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\modèle_linéaire_2\modèle_linéaire_2")
data=load(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\données_estimées.csv")
data_normal=load(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\données_estimées.csv")
data_changed=load(r"C:\Users\jt_ur\DA\projects\streamlit uploadé\données_estimées.csv")
st.write("On va dans un premier temps modifier le dataset des variables prédites par le modèle linéaire du carbone pour ensuite prévoir la température moyenne annuelle avec une seconde régression linéaire.")
liste_pays=st.multiselect("Choix des pays", ["Chine", "USA", "Russie", "Indonésie", "Brésil", "Inde", "France"])
liste_variables_causales=st.multiselect("Choix des variables causales", ["population", "Charbon", "Pétrole", "Gaz", "Changement_affectation_terres", "Ciment", "Torchage"])
réduction=st.slider("Choix de la baisse en pourcentage", 0, 100)
variables_causales=["population", "coal_co2", "oil_co2", "gas_co2", "land_use_change_co2", "cement_co2", "flaring_co2"]

new_liste_pays=[]
dict_translate_pays={"Chine":"China", "USA": "United States of America", "Russie": "Russia", "Indonésie": "Indonesia", "Brésil": "Brazil", "Inde": "India"}
for pays in liste_pays:
    if pays in dict_translate_pays.keys():
        pays=dict_translate_pays[pays]
        new_liste_pays.append(pays)
    else:
        new_liste_pays.append(pays)

new_liste_var=[]
dict_translate_var={'Charbon': "coal_co2", "Pétrole": "oil_co2", "Gaz": "gas_co2", "Ciment": "cement_co2", "Changement_affectation_terres":"land_use_change_co2", "Torchage":"flaring_co2" }
for var in liste_variables_causales:
    if var in dict_translate_var.keys():
        var=dict_translate_var[var]
        new_liste_var.append(var)
    else:
        new_liste_var.append(var)
        
liste_pays=new_liste_pays
liste_variables_causales=new_liste_var

data_normal[variables_causales]=scaler.transform(data_normal[variables_causales])
data_normal=pd.get_dummies(data_normal, columns=['pays', 'continent'])

co2_normal=model_1.predict(data_normal)

df_co2_normal=pd.DataFrame({'year': data.year, 'co2': co2_normal})
co2_moy_an_normal=df_co2_normal.groupby('year').agg('mean')

temperature_prevision_normal=model_2.predict(co2_moy_an_normal)

difference_normal=temperature_prevision_normal[-1]-temperature_prevision_normal[0]



liste_traitement=[]
durée=[an for an in range(2020, 2101)]
for pays in liste_pays:
    
    df=data.loc[data.pays==pays,:]
    df_first_var=df.loc[df.year==2020, liste_variables_causales]
    df_dec_var=df_first_var.apply(lambda x: x*(réduction/100)) 
    df_change_var=df_first_var-df_dec_var
    new_df=pd.DataFrame({}, index=durée)

    for var in liste_variables_causales:
    
        new_df[var]=np.linspace(float(df_first_var[var]), float(df_change_var[var]), len(durée))
        new_df['pays']=pays
    
    liste_traitement.append(new_df)

try:

    df_changed=pd.concat(liste_traitement)



    for pays in df_changed.pays.unique():
    
        for var in df_changed.columns:
        
            for line in durée:
            
                transit=df_changed[df_changed.pays==pays].loc[line, var]
                data_changed.loc[(data_changed.year==line) & (data_changed.pays==pays), var]=transit
   



    data_changed[variables_causales]=scaler.transform(data_changed[variables_causales])
    data_changed=pd.get_dummies(data_changed, columns=['pays', 'continent'])    

    co2_emission=model_1.predict(data_changed)

    df_co2_emission=pd.DataFrame({'year': data_changed.year, 'co2': co2_emission})
    co2_moy_an=df_co2_emission.groupby('year').agg('mean')

    temperature_prevision=model_2.predict(co2_moy_an)

    difference_changements=temperature_prevision[-1]-temperature_prevision[0]


    plt.clf()
    fig8, ax8=plt.subplots() 
    ax8.plot(durée, temperature_prevision, c='r',label='Prévisions avec modifications.')
    ax8.plot(durée, temperature_prevision_normal, c='b', label='Prévisions sans modifications.')
    ax8.legend()



    st.pyplot(fig8)
    st.write(f"Différence de température pour une évolution sans changements: {round(difference_normal,2)} degrés Celsius.")
    st.write(f"Différence de température pour une évolution avec changements: {round(difference_changements, 2)} degrés Celsius.")

except:
    
    plt.clf()
    fig8, ax8=plt.subplots()
    ax8.plot(durée, temperature_prevision_normal, c='b', label='Prévisions sans modifications.')
    ax8.legend()
    st.pyplot(fig8)
    st.write(f"Différence de température pour une évolution sans changements: {round(difference_normal, 2)} degrés Celsius.")

st.header("Partie trois: conclusion.")
st.write(" L'approche directe des forêts aléatoires et la prédiction Arima nous indique une augmentation de la température moyenne mondiale de presque 1.5 degrés d'ici l'année 2100.")
st.write("Ces deux modèles n'intègrent pas le co2, et prédisent donc la température si le co2 évolue conjointement de la même façon que pendant la période 1960/2020.")
st.write("Le modèle intégrant le co2 permet de prédire la température future au cas où des variables causales changeraient d'évolution.")
st.write("Si la Chine, la Russie, l'Inde, l'Indonésie, les USA et le Brésil venaient à réduire ces variables causales de 50%, le modèle nous prédit un équilibre de la température moyenne mondiale en 2100.")
st.write("Si la France n'émet plus de co2, en 2100 la température moyenne mondiale baissera d'un centième de degrés environ selon notre modèle.")
st.write("Il va donc falloir réduire de façon drastique les émissions co2 pour équilibrer au plus vite la température moyenne mondiale.")
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Apr  6 15:30:19 2023

@author: harry
"""

import streamlit as st

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.tsa.arima_model import ARIMA
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.stattools import adfuller
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from sklearn.metrics import mean_squared_error

from joblib import load, dump

st.title('Modélisation de la température future')
st.header('Evolution mondiale des températures entre 1960 et 2019')
st.write("Avec les données du 'Climate Change Knowledge Portal', et une régression linéaire sur chaque point géographique, l'évolution est visualisée avec le coefficient de la régression pour chaque point. Les points rouges sonts les zones les plus impactées.")
st.image("/home/harry/projet datascientest/streamlit/carte evolution temperature.png")
st.header('Evolution mondiale des températures pour 2100, 2500 et 2100.')
st.write("Les prédictions sont faites avec différents modèles de machine learning au choix.")
machine_learning_model=st.selectbox('Sélection du modèle de machine learning.', ['forets aléatoires', 'régression linéaire générale', 'régression polynomiale générale', 'régression linéaire par point géographique', 'régression polynomiale par point géographique'])
year_prediction=st.selectbox("Sélection de l'année à prédire.", ['2100', '2500', '3000'])

if (machine_learning_model=='forets aléatoires') and (year_prediction=='2100'):
    
    st.image('/home/harry/projet datascientest/streamlit/carte prevision foret 2100')

elif (machine_learning_model=='forets aléatoires') and (year_prediction=='2500'):
    
    st.image('/home/harry/projet datascientest/streamlit/carte prediction 2500 foret')
    
elif (machine_learning_model=='forets aléatoires') and (year_prediction=='3000'):
    
    st.image('/home/harry/projet datascientest/streamlit/carte prediction foret 3000')
    
elif (machine_learning_model=='régression linéaire par point géographique') and (year_prediction=='2100'):
    
    st.image('/home/harry/projet datascientest/streamlit/carte regression lineaire 2100 ')
    
elif (machine_learning_model=='régression linéaire par point géographique') and (year_prediction=='2500'):
    
    st.image('/home/harry/projet datascientest/streamlit/carte linearbypoint prediction 2500')
    
elif (machine_learning_model=='régression linéaire par point géographique') and (year_prediction=='3000'):
    
    st.image('/home/harry/projet datascientest/streamlit/carte prediction lineaire 3000')
    
elif (machine_learning_model=='régression polynomiale par point géographique') and (year_prediction=='2100'):
    
    st.image('/home/harry/projet datascientest/streamlit/carte prediction poly 2100')
    
elif (machine_learning_model=='régression polynomiale par point géographique') and (year_prediction=='2500'):
    
    st.image('/home/harry/projet datascientest/streamlit/carte prediction poly 2500')
    
elif (machine_learning_model=='régression polynomiale par point géographique') and (year_prediction=='3000'):
    
    st.image('/home/harry/projet datascientest/streamlit/carte prevision poly 3000')
    
elif (machine_learning_model=='régression linéaire générale') and (year_prediction=='2100'):
    
    st.image('/home/harry/projet datascientest/streamlit/carte prevision linear gene2100')

elif (machine_learning_model=='régression linéaire générale') and (year_prediction=='2500'):
    
    st.image('/home/harry/projet datascientest/streamlit/carte prevision linear gene 2500')
    
elif (machine_learning_model=='régression linéaire générale') and (year_prediction=='3000'):
    
    st.image('/home/harry/projet datascientest/streamlit/carte prevision linear gene 3000')
    
elif (machine_learning_model=='régression polynomiale générale') and (year_prediction=='2100'):
    
    st.image('/home/harry/projet datascientest/streamlit/carte prediciotn poly gene2100')
    
elif (machine_learning_model=='régression polynomiale générale') and (year_prediction=='2500'):
    
    st.image('/home/harry/projet datascientest/streamlit/carte prediction temperature poly gene2500')

elif (machine_learning_model=='régression polynomiale générale') and (year_prediction=='3000'):
    
    st.image('/home/harry/projet datascientest/streamlit/carte prediction 3000 poly gene')
    
    
st.header("Evolution de la température avec ARIMA (série temporelle)")
st.write("Le modele ARIMA permet d'estimer dans le temps l'évolution de la température ainsi que du co2.")
st.header('A propos de la température, paramètres:')
annee_prediction=st.number_input("Année de prédiction", 2050, 2500, step=50)
differentiation=st.number_input("Ordre de différentiation", 0, 1)
AR=st.number_input("Paramètre du processus AR", 0, 5)
MA=st.number_input("Paramètre du processus MA", 0, 5)

data=pd.read_csv('/home/harry/projet datascientest/selection_programmes_resuite/data_temperature_co2_anomalie.csv', index_col=0)
temperature=data[['year', 'température']].groupby('year').agg('mean')
temperature.index=pd.date_range('1960-06-01', '2020-06-01', freq='y')

"""
annee_prediction=2100
differentiation=1
AR=2
MA=2
"""

if differentiation==0:
    diff=temperature
elif differentiation==1:
    diff=temperature.diff().dropna()

    
ax2=seasonal_decompose(diff).plot()
st.header("Décomposition des données selon nos paramètres sur la température:")
st.pyplot(ax2)
result2=adfuller(diff.température)

st.header("Statistiques AD-Fuller.")
st.write(f"Statistiques ADF: {round(result2[0], 2)}")
st.write(f"P-value: {round(result2[1], 2)}")
if result2[1]<0.05:
    st.write("Le modèle est stationnaire.")
elif result2[1]>=0.05:
    st.write("Le modèle n'est pas stationnaire.")


st.header("Autocorrélation partielle de la série.")
ax3=plot_pacf(diff)
st.pyplot(ax3)
st.write("Doit tendre vers 0. Permet surtout visuellement de régler le paramètre AR. S'annule généralement après le paramètre AR.")

st.header("Autocorrélation simple de la série.")
ax4=plot_acf(diff)
st.pyplot(ax4)
st.write("Doit également tendre vers 0. S'annule en général après le paramètre MA.")

st.header("Prédictions Arima de la température.")
model=ARIMA(temperature, order=(AR, differentiation, MA))
prediction_arima=model.fit()
pred_debut=prediction_arima.predict(differentiation, end=60, typ='levels')
ax5=prediction_arima.plot_predict(differentiation, annee_prediction-1960)
st.pyplot(ax5)

if differentiation==0:
    pred_debut=pred_debut[:-1]


pre=prediction_arima.predict(60, end=annee_prediction-1960, typ='levels')
debut=pre[0]
fin=pre[-1]
erreur=mean_squared_error(temperature[:60], pred_debut)
st.write(f"Erreur quadratique moyenne: {round(erreur,5)}.")
st.write(f"Différence de température: {round(fin-debut, 2)} degrés Celsius.")

st.header("Prédictions des modèles de régression linéaire pour 2100.")

scaler=load('/home/harry/projet datascientest/streamlit/scaler_modele_1.gz')
model_1=load('/home/harry/projet datascientest/streamlit/modele_lineaire_1.gz')
model_2=load('/home/harry/projet datascientest/streamlit/modèle_linéaire_2.gz')
data=load('/home/harry/projet datascientest/streamlit/données_estimées.csv')
data_normal=load('/home/harry/projet datascientest/streamlit/données_estimées.csv')
data_changed=load('/home/harry/projet datascientest/streamlit/données_estimées.csv')
st.write("On va dans un premier temps modifier le dataset des variables prédites par le modèle linéaire du carbone pour ensuite prévoir la température moyenne annuelle avec une seconde régression linéaire.")
liste_pays=st.multiselect("Choix des pays", ["China", "United States of America", "Russia", "Indonesia", "Brazil", "India", "France"])
liste_variables_causales=st.multiselect("Choix des variables causales", ["population", "coal_co2", "oil_co2", "gas_co2", "land_use_change_co2", "cement_co2", "flaring_co2"])
réduction=st.slider("Choix de la baisse en pourcentage", -200, 200)
variables_causales=["population", "coal_co2", "oil_co2", "gas_co2", "land_use_change_co2", "cement_co2", "flaring_co2"]



data_normal[variables_causales]=scaler.transform(data_normal[variables_causales])
data_normal=pd.get_dummies(data_normal, columns=['pays', 'continent'])

co2_normal=model_1.predict(data_normal)

df_co2_normal=pd.DataFrame({'year': data.year, 'co2': co2_normal})
co2_moy_an_normal=df_co2_normal.groupby('year').agg('mean')

temperature_prevision_normal=model_2.predict(co2_moy_an_normal)

difference_normal=temperature_prevision_normal[-1]-temperature_prevision_normal[0]



liste_traitement=[]
durée=[an for an in range(2020, 2101)]
for pays in liste_pays:
    
    df=data.loc[data.pays==pays,:]
    df_first_var=df.loc[df.year==2020, liste_variables_causales]
    df_dec_var=df_first_var.apply(lambda x: x*(réduction/100)) 
    df_change_var=df_first_var-df_dec_var
    new_df=pd.DataFrame({}, index=durée)

    for var in liste_variables_causales:
    
        new_df[var]=np.linspace(float(df_first_var[var]), float(df_change_var[var]), len(durée))
        new_df['pays']=pays
    
    liste_traitement.append(new_df)

try:

    df_changed=pd.concat(liste_traitement)



    for pays in df_changed.pays.unique():
    
        for var in df_changed.columns:
        
            for line in durée:
            
                transit=df_changed[df_changed.pays==pays].loc[line, var]
                data_changed.loc[(data_changed.year==line) & (data_changed.pays==pays), var]=transit
   



    data_changed[variables_causales]=scaler.transform(data_changed[variables_causales])
    data_changed=pd.get_dummies(data_changed, columns=['pays', 'continent'])    

    co2_emission=model_1.predict(data_changed)

    df_co2_emission=pd.DataFrame({'year': data_changed.year, 'co2': co2_emission})
    co2_moy_an=df_co2_emission.groupby('year').agg('mean')

    temperature_prevision=model_2.predict(co2_moy_an)

    difference_changements=temperature_prevision[-1]-temperature_prevision[0]


    plt.clf()
    fig8, ax8=plt.subplots() 
    ax8.plot(durée, temperature_prevision, c='r',label='Prévisions avec modifications.')
    ax8.plot(durée, temperature_prevision_normal, c='b', label='Prévisions sans modifications.')
    ax8.legend()



    st.pyplot(fig8)
    st.write(f"Différence de température pour une évolution sans changements: {round(difference_normal,2)} degrés Celsius.")
    st.write(f"Différence de température pour une évolution avec changements: {round(difference_changements, 2)} degrés Celsius.")

except:
    
    plt.clf()
    fig8, ax8=plt.subplots()
    ax8.plot(durée, temperature_prevision_normal, c='b', label='Prévisions sans modifications.')
    ax8.legend()
    st.pyplot(fig8)
    st.write(f"Différence de température pour une évolution sans changements: {round(difference_normal, 2)} degrés Celsius.")